import { pgTable, text, serial, integer, timestamp, boolean, decimal, json, real, jsonb } from 'drizzle-orm/pg-core';
import { createInsertSchema, createSelectSchema } from 'drizzle-zod';
import { relations } from 'drizzle-orm';
import { z } from 'zod';

// Asset types table
export const assetTypes = pgTable('asset_types', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// Assets table
export const assets = pgTable('assets', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  symbol: text('symbol').notNull().unique(),
  typeId: integer('type_id').references(() => assetTypes.id).notNull(),
  logoUrl: text('logo_url'),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Strategies table
export const strategies = pgTable('strategies', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description'),
  allocation: real('allocation').notNull().default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Performance metrics table
export const performanceMetrics = pgTable('performance_metrics', {
  id: serial('id').primaryKey(),
  assetId: integer('asset_id').references(() => assets.id).notNull(),
  strategyId: integer('strategy_id').references(() => strategies.id),
  testAllocation: real('test_allocation').notNull(),
  backtestReturn: real('backtest_return').notNull(),
  winRate: real('win_rate').notNull(),
  confidence: real('confidence').notNull(),
  status: text('status').notNull(),
  startDate: timestamp('start_date').notNull(),
  endDate: timestamp('end_date').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// AI models table
export const aiModels = pgTable('ai_models', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  epoch: integer('epoch').notNull().default(0),
  totalEpochs: integer('total_epochs').notNull(),
  accuracy: real('accuracy').notNull().default(0),
  precision: real('precision').notNull().default(0),
  recall: real('recall').notNull().default(0),
  f1Score: real('f1_score').notNull().default(0),
  networkDepth: integer('network_depth').notNull(),
  parameters: text('parameters').notNull(),
  optimizationAlgorithm: text('optimization_algorithm').notNull(),
  learningRate: real('learning_rate').notNull(),
  dataProcessed: real('data_processed').notNull().default(0),
  isActive: boolean('is_active').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Market insights table
export const marketInsights = pgTable('market_insights', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  analysisType: text('analysis_type').notNull(),
  severity: text('severity').notNull(),
  confidence: real('confidence').notNull(),
  tags: text('tags').array(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// Data sources table
export const dataSources = pgTable('data_sources', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description'),
  type: text('type').notNull(),
  isConnected: boolean('is_connected').default(false),
  apiKey: text('api_key'),
  endpoint: text('endpoint'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Trading settings table
export const tradingSettings = pgTable('trading_settings', {
  id: serial('id').primaryKey(),
  liveMode: boolean('live_mode').default(false).notNull(),
  maxPortfolioRisk: real('max_portfolio_risk').default(10).notNull(), // percentage
  maxPositionSize: real('max_position_size').default(5).notNull(), // percentage
  maxDailyDrawdown: real('max_daily_drawdown').default(3).notNull(), // percentage
  maxTotalDrawdown: real('max_total_drawdown').default(15).notNull(), // percentage
  tradingFrequency: text('trading_frequency').notNull().default('daily'),
  defaultOrderType: text('default_order_type').notNull().default('market'),
  useTakeProfits: boolean('use_take_profits').default(true).notNull(),
  useStopLosses: boolean('use_stop_losses').default(true).notNull(),
  defaultTakeProfitPct: real('default_take_profit_pct').default(10).notNull(),
  defaultStopLossPct: real('default_stop_loss_pct').default(5).notNull(),
  rebalancingFrequency: text('rebalancing_frequency').notNull().default('weekly'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Trading transactions table
export const tradingTransactions = pgTable('trading_transactions', {
  id: serial('id').primaryKey(),
  assetId: integer('asset_id').references(() => assets.id).notNull(),
  strategyId: integer('strategy_id').references(() => strategies.id),
  transactionType: text('transaction_type').notNull(), // buy, sell
  orderType: text('order_type').notNull(), // market, limit
  price: decimal('price', { precision: 18, scale: 8 }).notNull(),
  quantity: decimal('quantity', { precision: 18, scale: 8 }).notNull(),
  totalValue: decimal('total_value', { precision: 18, scale: 8 }).notNull(),
  status: text('status').notNull().default('pending'), // pending, completed, failed, cancelled
  exchange: text('exchange'),
  externalId: text('external_id'),
  confidence: real('confidence'),
  reasoning: text('reasoning'),
  metadata: jsonb('metadata'),
  isDemo: boolean('is_demo').default(true).notNull(),
  executedAt: timestamp('executed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Trading API connections table
export const tradingApiConnections = pgTable('trading_api_connections', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  provider: text('provider').notNull(), // e.g., 'alpaca', 'binance', 'interactive_brokers'
  apiKey: text('api_key'),
  apiSecret: text('api_secret'),
  isActive: boolean('is_active').default(true).notNull(),
  supportedAssetTypes: text('supported_asset_types').array(),
  metadata: jsonb('metadata'),
  lastConnected: timestamp('last_connected'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Define relations
export const assetsRelations = relations(assets, ({ one, many }) => ({
  type: one(assetTypes, { fields: [assets.typeId], references: [assetTypes.id] }),
  performanceMetrics: many(performanceMetrics)
}));

export const assetTypesRelations = relations(assetTypes, ({ many }) => ({
  assets: many(assets)
}));

export const strategiesRelations = relations(strategies, ({ many }) => ({
  performanceMetrics: many(performanceMetrics)
}));

export const performanceMetricsRelations = relations(performanceMetrics, ({ one }) => ({
  asset: one(assets, { fields: [performanceMetrics.assetId], references: [assets.id] }),
  strategy: one(strategies, { fields: [performanceMetrics.strategyId], references: [strategies.id] })
}));

export const tradingTransactionsRelations = relations(tradingTransactions, ({ one }) => ({
  asset: one(assets, { fields: [tradingTransactions.assetId], references: [assets.id] }),
  strategy: one(strategies, { fields: [tradingTransactions.strategyId], references: [strategies.id] })
}));

// Define schemas
export const assetTypesInsertSchema = createInsertSchema(assetTypes, {
  name: (schema) => schema.min(2, "Type name must be at least 2 characters"),
  description: (schema) => schema.optional()
});
export type AssetTypeInsert = z.infer<typeof assetTypesInsertSchema>;
export type AssetType = typeof assetTypes.$inferSelect;

export const assetsInsertSchema = createInsertSchema(assets, {
  name: (schema) => schema.min(2, "Asset name must be at least 2 characters"),
  symbol: (schema) => schema.min(1, "Symbol is required"),
  description: (schema) => schema.optional(),
  logoUrl: (schema) => schema.optional()
});
export type AssetInsert = z.infer<typeof assetsInsertSchema>;
export type Asset = typeof assets.$inferSelect;

export const strategiesInsertSchema = createInsertSchema(strategies, {
  name: (schema) => schema.min(2, "Strategy name must be at least 2 characters"),
  description: (schema) => schema.optional(),
  allocation: (schema) => schema.min(0, "Allocation must be a positive number"),
  isActive: (schema) => schema.optional()
});
export type StrategyInsert = z.infer<typeof strategiesInsertSchema>;
export type Strategy = typeof strategies.$inferSelect;

export const performanceMetricsInsertSchema = createInsertSchema(performanceMetrics, {
  assetId: (schema) => schema.positive("Asset ID is required"),
  strategyId: (schema) => schema.optional(),
  testAllocation: (schema) => schema.min(0, "Test allocation must be a positive number"),
  backtestReturn: (schema) => schema,
  winRate: (schema) => schema.min(0, "Win rate must be between 0 and 100").max(100, "Win rate must be between 0 and 100"),
  confidence: (schema) => schema.min(0, "Confidence must be between 0 and 100").max(100, "Confidence must be between 0 and 100"),
  status: (schema) => schema
});
export type PerformanceMetricInsert = z.infer<typeof performanceMetricsInsertSchema>;
export type PerformanceMetric = typeof performanceMetrics.$inferSelect;

export const aiModelsInsertSchema = createInsertSchema(aiModels, {
  name: (schema) => schema.min(2, "Model name must be at least 2 characters"),
  description: (schema) => schema.optional(),
  epoch: (schema) => schema.min(0, "Epoch must be a positive number"),
  totalEpochs: (schema) => schema.min(1, "Total epochs must be at least 1"),
  accuracy: (schema) => schema.min(0, "Accuracy must be between 0 and 100").max(100, "Accuracy must be between 0 and 100"),
  precision: (schema) => schema.min(0, "Precision must be between 0 and 100").max(100, "Precision must be between 0 and 100"),
  recall: (schema) => schema.min(0, "Recall must be between 0 and 100").max(100, "Recall must be between 0 and 100"),
  f1Score: (schema) => schema.min(0, "F1 score must be between 0 and 100").max(100, "F1 score must be between 0 and 100")
});
export type AIModelInsert = z.infer<typeof aiModelsInsertSchema>;
export type AIModel = typeof aiModels.$inferSelect;

export const marketInsightsInsertSchema = createInsertSchema(marketInsights, {
  title: (schema) => schema.min(5, "Title must be at least 5 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
  analysisType: (schema) => schema.min(2, "Analysis type is required"),
  severity: (schema) => schema.min(2, "Severity is required"),
  confidence: (schema) => schema.min(0, "Confidence must be between 0 and 100").max(100, "Confidence must be between 0 and 100")
});
export type MarketInsightInsert = z.infer<typeof marketInsightsInsertSchema>;
export type MarketInsight = typeof marketInsights.$inferSelect;

export const dataSourcesInsertSchema = createInsertSchema(dataSources, {
  name: (schema) => schema.min(2, "Source name must be at least 2 characters"),
  description: (schema) => schema.optional(),
  type: (schema) => schema.min(2, "Type is required"),
  isConnected: (schema) => schema.optional(),
  apiKey: (schema) => schema.optional(),
  endpoint: (schema) => schema.optional()
});
export type DataSourceInsert = z.infer<typeof dataSourcesInsertSchema>;
export type DataSource = typeof dataSources.$inferSelect;

export const tradingSettingsInsertSchema = createInsertSchema(tradingSettings, {
  liveMode: (schema) => schema,
  maxPortfolioRisk: (schema) => schema.min(0, "Portfolio risk must be between 0 and 100").max(100, "Portfolio risk must be between 0 and 100"),
  maxPositionSize: (schema) => schema.min(0, "Position size must be between 0 and 100").max(100, "Position size must be between 0 and 100"),
  maxDailyDrawdown: (schema) => schema.min(0, "Daily drawdown must be between 0 and 100").max(100, "Daily drawdown must be between 0 and 100"),
  maxTotalDrawdown: (schema) => schema.min(0, "Total drawdown must be between 0 and 100").max(100, "Total drawdown must be between 0 and 100"),
  tradingFrequency: (schema) => schema.refine(val => ['hourly', 'daily', 'weekly'].includes(val), "Trading frequency must be 'hourly', 'daily', or 'weekly'"),
  defaultOrderType: (schema) => schema.refine(val => ['market', 'limit', 'stop'].includes(val), "Order type must be 'market', 'limit', or 'stop'"),
  useTakeProfits: (schema) => schema,
  useStopLosses: (schema) => schema,
  defaultTakeProfitPct: (schema) => schema.min(0, "Take profit percentage must be positive"),
  defaultStopLossPct: (schema) => schema.min(0, "Stop loss percentage must be positive"),
  rebalancingFrequency: (schema) => schema.refine(val => ['daily', 'weekly', 'monthly', 'quarterly'].includes(val), "Rebalancing frequency must be 'daily', 'weekly', 'monthly', or 'quarterly'")
});
export type TradingSettingsInsert = z.infer<typeof tradingSettingsInsertSchema>;
export type TradingSettings = typeof tradingSettings.$inferSelect;

export const tradingTransactionsInsertSchema = createInsertSchema(tradingTransactions, {
  assetId: (schema) => schema.min(1, "Asset ID is required"),
  strategyId: (schema) => schema.optional(),
  transactionType: (schema) => schema.refine(val => ['buy', 'sell'].includes(val), "Transaction type must be 'buy' or 'sell'"),
  orderType: (schema) => schema.refine(val => ['market', 'limit', 'stop'].includes(val), "Order type must be 'market', 'limit', or 'stop'"),
  price: (schema) => schema.refine(val => parseFloat(val) > 0, "Price must be positive"),
  quantity: (schema) => schema.refine(val => parseFloat(val) > 0, "Quantity must be positive"),
  totalValue: (schema) => schema.refine(val => parseFloat(val) > 0, "Total value must be positive"),
  status: (schema) => schema.refine(val => ['pending', 'completed', 'failed', 'cancelled'].includes(val), "Status must be 'pending', 'completed', 'failed', or 'cancelled'"),
  exchange: (schema) => schema.optional(),
  externalId: (schema) => schema.optional(),
  confidence: (schema) => schema.optional(),
  reasoning: (schema) => schema.optional(),
  metadata: (schema) => schema.optional(),
  isDemo: (schema) => schema,
  executedAt: (schema) => schema.optional()
});
export type TradingTransactionInsert = z.infer<typeof tradingTransactionsInsertSchema>;
export type TradingTransaction = typeof tradingTransactions.$inferSelect;

export const tradingApiConnectionsInsertSchema = createInsertSchema(tradingApiConnections, {
  name: (schema) => schema.min(2, "Connection name must be at least 2 characters"),
  provider: (schema) => schema.min(2, "Provider is required"),
  apiKey: (schema) => schema.optional(),
  apiSecret: (schema) => schema.optional(),
  isActive: (schema) => schema,
  supportedAssetTypes: (schema) => schema.optional(),
  metadata: (schema) => schema.optional(),
  lastConnected: (schema) => schema.optional()
});
export type TradingApiConnectionInsert = z.infer<typeof tradingApiConnectionsInsertSchema>;
export type TradingApiConnection = typeof tradingApiConnections.$inferSelect;
