import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  try {
    console.log("Starting database seeding...");

    // ---- Asset Types ----
    console.log("Seeding asset types...");
    const assetTypes = await db.insert(schema.assetTypes)
      .values([
        { name: "Cryptocurrency", description: "Digital or virtual currencies that use cryptography for security" },
        { name: "Stock", description: "A type of security that signifies ownership in a corporation" },
        { name: "Index Fund", description: "A type of mutual fund with a portfolio constructed to match a market index" },
        { name: "Commodity", description: "A basic good used in commerce that is interchangeable with other goods of the same type" },
        { name: "Forex", description: "The market in which currencies are traded" }
      ])
      .returning();
    
    console.log(`Added ${assetTypes.length} asset types`);

    // Create a map for easy lookup
    const assetTypeMap = assetTypes.reduce((acc, type) => {
      acc[type.name] = type.id;
      return acc;
    }, {} as Record<string, number>);

    // ---- Assets ----
    console.log("Seeding assets...");
    const assets = await db.insert(schema.assets)
      .values([
        { 
          name: "Bitcoin", 
          symbol: "BTC", 
          typeId: assetTypeMap["Cryptocurrency"], 
          logoUrl: "https://cryptologos.cc/logos/bitcoin-btc-logo.svg", 
          description: "The first decentralized cryptocurrency, based on blockchain technology" 
        },
        { 
          name: "Ethereum", 
          symbol: "ETH", 
          typeId: assetTypeMap["Cryptocurrency"], 
          logoUrl: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", 
          description: "An open-source blockchain platform featuring smart contract functionality" 
        },
        { 
          name: "S&P 500", 
          symbol: "SPY", 
          typeId: assetTypeMap["Index Fund"], 
          logoUrl: "", 
          description: "An index of 500 large companies listed on stock exchanges in the United States" 
        },
        { 
          name: "NVIDIA", 
          symbol: "NVDA", 
          typeId: assetTypeMap["Stock"], 
          logoUrl: "", 
          description: "An American multinational technology company that designs graphics processing units" 
        },
        { 
          name: "Gold", 
          symbol: "GLD", 
          typeId: assetTypeMap["Commodity"], 
          logoUrl: "", 
          description: "A precious metal used as an investment, reserve currency, and in jewelry" 
        }
      ])
      .returning();
    
    console.log(`Added ${assets.length} assets`);

    // Create a map for easy lookup
    const assetMap = assets.reduce((acc, asset) => {
      acc[asset.symbol] = asset.id;
      return acc;
    }, {} as Record<string, number>);

    // ---- Strategies ----
    console.log("Seeding strategies...");
    const strategies = await db.insert(schema.strategies)
      .values([
        { 
          name: "Trend Following", 
          description: "Strategy that follows the momentum of the market, buying assets that are rising and selling those that are falling", 
          allocation: 42.0,
          isActive: true
        },
        { 
          name: "Mean Reversion", 
          description: "Strategy based on the idea that prices will revert to their historical average over time", 
          allocation: 28.0,
          isActive: true
        },
        { 
          name: "Breakout Trading", 
          description: "Strategy that enters positions when price breaks through established support or resistance levels", 
          allocation: 15.0,
          isActive: true
        },
        { 
          name: "Sentiment Analysis", 
          description: "Strategy that analyzes market sentiment from news, social media, and other sources to make trading decisions", 
          allocation: 10.0,
          isActive: true
        },
        { 
          name: "Statistical Arbitrage", 
          description: "Strategy that exploits pricing inefficiencies between related assets", 
          allocation: 5.0,
          isActive: true
        }
      ])
      .returning();
    
    console.log(`Added ${strategies.length} strategies`);

    // Create a map for easy lookup
    const strategyMap = strategies.reduce((acc, strategy) => {
      acc[strategy.name] = strategy.id;
      return acc;
    }, {} as Record<string, number>);

    // ---- Performance Metrics ----
    console.log("Seeding performance metrics...");
    const now = new Date();
    const sixMonthsAgo = new Date(now);
    sixMonthsAgo.setMonth(now.getMonth() - 6);

    await db.insert(schema.performanceMetrics)
      .values([
        {
          assetId: assetMap["BTC"],
          strategyId: strategyMap["Trend Following"],
          testAllocation: 25.0,
          backtestReturn: 31.4,
          winRate: 78.0,
          confidence: 85.0,
          status: "Optimized",
          startDate: sixMonthsAgo,
          endDate: now
        },
        {
          assetId: assetMap["SPY"],
          strategyId: strategyMap["Mean Reversion"],
          testAllocation: 20.0,
          backtestReturn: 18.2,
          winRate: 82.0,
          confidence: 90.0,
          status: "Optimized",
          startDate: sixMonthsAgo,
          endDate: now
        },
        {
          assetId: assetMap["NVDA"],
          strategyId: strategyMap["Breakout Trading"],
          testAllocation: 15.0,
          backtestReturn: 42.8,
          winRate: 74.0,
          confidence: 70.0,
          status: "Learning",
          startDate: sixMonthsAgo,
          endDate: now
        },
        {
          assetId: assetMap["GLD"],
          strategyId: strategyMap["Statistical Arbitrage"],
          testAllocation: 10.0,
          backtestReturn: -4.2,
          winRate: 45.0,
          confidence: 45.0,
          status: "Needs Review",
          startDate: sixMonthsAgo,
          endDate: now
        },
        {
          assetId: assetMap["ETH"],
          strategyId: strategyMap["Sentiment Analysis"],
          testAllocation: 20.0,
          backtestReturn: 27.6,
          winRate: 72.0,
          confidence: 75.0,
          status: "In Progress",
          startDate: sixMonthsAgo,
          endDate: now
        }
      ]);
    
    console.log("Added performance metrics");

    // ---- AI Models ----
    console.log("Seeding AI models...");
    await db.insert(schema.aiModels)
      .values([
        {
          name: "TradeSage Neural Network v1",
          description: "Deep learning model for market prediction and trading strategy optimization",
          epoch: 257,
          totalEpochs: 500,
          accuracy: 87.2,
          precision: 82.7,
          recall: 79.4,
          f1Score: 81.0,
          networkDepth: 7,
          parameters: "145.6M",
          optimizationAlgorithm: "Adam",
          learningRate: 0.0001,
          dataProcessed: 4.2, // TB
          isActive: true
        }
      ]);
    
    console.log("Added AI model");

    // ---- Market Insights ----
    console.log("Seeding market insights...");
    // Create timestamps for the insights
    const twoHoursAgo = new Date(now);
    twoHoursAgo.setHours(now.getHours() - 2);
    
    const fiveHoursAgo = new Date(now);
    fiveHoursAgo.setHours(now.getHours() - 5);
    
    const twelveHoursAgo = new Date(now);
    twelveHoursAgo.setHours(now.getHours() - 12);
    
    const oneDayAgo = new Date(now);
    oneDayAgo.setDate(now.getDate() - 1);

    await db.insert(schema.marketInsights)
      .values([
        {
          title: "Bull Market Trend Detected",
          description: "Analysis of market indicators suggests a bullish trend forming across tech sectors. Pattern recognition models indicate 78% probability of continuation.",
          analysisType: "Trend Analysis",
          severity: "success",
          confidence: 78.0,
          tags: ["Tech Sector", "Bullish", "High Confidence"],
          createdAt: twoHoursAgo
        },
        {
          title: "Cryptocurrency Volatility Increasing",
          description: "Volatility metrics indicate increased fluctuation in major cryptocurrencies. Model suggests a 63% probability of a short-term correction followed by recovery.",
          analysisType: "Volatility Analysis",
          severity: "warning",
          confidence: 63.0,
          tags: ["Cryptocurrency", "Volatile", "Medium Confidence"],
          createdAt: fiveHoursAgo
        },
        {
          title: "Sector Rotation Opportunity",
          description: "Economic indicators and sentiment analysis suggest rotation from growth to value stocks. Model predicts outperformance in financial and energy sectors.",
          analysisType: "Sector Analysis",
          severity: "primary",
          confidence: 70.0,
          tags: ["Sector Rotation", "Value Stocks", "Actionable"],
          createdAt: twelveHoursAgo
        },
        {
          title: "Risk Alert: Commodity Pressure",
          description: "Supply chain analysis indicates potential pricing pressure in industrial commodities. Model suggests hedging exposure in manufacturing and materials sectors.",
          analysisType: "Risk Analysis",
          severity: "danger",
          confidence: 65.0,
          tags: ["Commodities", "Risk Management", "Caution"],
          createdAt: oneDayAgo
        }
      ]);
    
    console.log("Added market insights");

    // ---- Data Sources ----
    console.log("Seeding data sources...");
    await db.insert(schema.dataSources)
      .values([
        {
          name: "Alpha Vantage API",
          description: "Stock market data",
          type: "Market Data",
          isConnected: true,
          apiKey: "",
          endpoint: "https://www.alphavantage.co/query"
        },
        {
          name: "CoinGecko API",
          description: "Cryptocurrency data",
          type: "Crypto Data",
          isConnected: true,
          apiKey: "",
          endpoint: "https://api.coingecko.com/api/v3"
        },
        {
          name: "News API",
          description: "Market news & sentiment",
          type: "News",
          isConnected: true,
          apiKey: "",
          endpoint: "https://newsapi.org/v2"
        },
        {
          name: "Economic Indicators",
          description: "Macroeconomic data",
          type: "Economic",
          isConnected: false,
          apiKey: "",
          endpoint: "https://api.economicdata.org"
        }
      ]);
    
    console.log("Added data sources");

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error during database seeding:", error);
    throw error;
  }
}

// Execute the seed function
seed().catch(error => {
  console.error("Failed to seed database:", error);
  process.exit(1);
});
