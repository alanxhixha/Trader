import { db } from "@db";
import { 
  assets, 
  assetTypes, 
  strategies, 
  performanceMetrics, 
  aiModels, 
  marketInsights, 
  dataSources,
  tradingSettings,
  tradingTransactions,
  tradingApiConnections
} from "@shared/schema";
import { and, eq, gte, desc } from "drizzle-orm";

class Storage {
  // Trading methods
  async getTradingSettings() {
    const settings = await db.query.tradingSettings.findMany({
      limit: 1,
      orderBy: desc(tradingSettings.updatedAt)
    });
    
    return settings.length > 0 ? settings[0] : null;
  }
  
  async updateTradingSettings(settingsData) {
    const currentSettings = await this.getTradingSettings();
    
    if (currentSettings) {
      const [updated] = await db.update(tradingSettings)
        .set({
          ...settingsData,
          updatedAt: new Date()
        })
        .where(eq(tradingSettings.id, currentSettings.id))
        .returning();
      return updated;
    } else {
      const [newSettings] = await db.insert(tradingSettings)
        .values({
          ...settingsData,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
      return newSettings;
    }
  }
  
  async toggleLiveTrading(enableLive) {
    return await this.updateTradingSettings({ liveMode: enableLive });
  }
  
  async getRecentTransactions(limit = 20, demoOnly = true) {
    return await db.query.tradingTransactions.findMany({
      limit,
      where: demoOnly ? eq(tradingTransactions.isDemo, true) : undefined,
      orderBy: desc(tradingTransactions.createdAt),
      with: {
        asset: true,
        strategy: true
      }
    });
  }
  
  async createTransaction(transactionData) {
    const settings = await this.getTradingSettings();
    const isDemo = settings ? !settings.liveMode : true; // Default to demo if no settings
    
    const [newTransaction] = await db.insert(tradingTransactions)
      .values({
        ...transactionData,
        isDemo,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    
    return newTransaction;
  }
  
  async getApiConnections() {
    return await db.query.tradingApiConnections.findMany({
      orderBy: desc(tradingApiConnections.updatedAt)
    });
  }
  
  // AI Trading Core
  async analyzeMarket() {
    // This would integrate with the actual AI model
    // For now, we'll simulate the analysis process
    
    const assets = await this.getAssets();
    const insights = [];
    
    for (const asset of assets) {
      // Generate simulated analysis for demonstration
      const sentiment = Math.random() > 0.5 ? 'bullish' : 'bearish';
      const confidence = 50 + Math.floor(Math.random() * 40); // 50-90%
      const action = sentiment === 'bullish' ? 'buy' : 'sell';
      
      insights.push({
        asset,
        sentiment,
        confidence,
        action,
        reasoning: `The AI model detected a ${sentiment} pattern for ${asset.name} based on recent price action and market indicators.`,
        timestamp: new Date()
      });
    }
    
    return insights;
  }
  
  async executeTradeRecommendation(assetId, action, price, quantity, confidence, reasoning) {
    const settings = await this.getTradingSettings();
    const isDemo = settings ? !settings.liveMode : true; // Default to demo if no settings
    
    // Determine which strategy to use
    const strategies = await this.getStrategies();
    const strategy = strategies.find(s => s.isActive) || strategies[0];
    
    // Create a new transaction
    const transaction = await this.createTransaction({
      assetId,
      strategyId: strategy?.id,
      transactionType: action, // 'buy' or 'sell'
      orderType: settings?.defaultOrderType || 'market',
      price,
      quantity,
      totalValue: price * quantity,
      status: 'pending',
      exchange: 'auto-selected',
      confidence,
      reasoning,
      isDemo,
      executedAt: new Date()
    });
    
    // In a real system, this would connect to actual trading APIs if not in demo mode
    // For now, we'll simulate the execution
    setTimeout(async () => {
      // Simulate the trade being executed
      const [completedTransaction] = await db.update(tradingTransactions)
        .set({
          status: 'completed',
          updatedAt: new Date()
        })
        .where(eq(tradingTransactions.id, transaction.id))
        .returning();
      
      // In a real system, we would also update portfolio holdings
    }, 2000); // Simulate a 2-second delay for execution
    
    return transaction;
  }
  
  // AI Model methods
  async getCurrentAIModel() {
    const models = await db.query.aiModels.findMany({
      orderBy: desc(aiModels.updatedAt),
      limit: 1
    });
    
    if (models.length === 0) {
      return null;
    }
    
    const model = models[0];
    
    // Calculate progress and time remaining
    const progress = (model.epoch / model.totalEpochs) * 100;
    const epochsRemaining = model.totalEpochs - model.epoch;
    const timePerEpoch = 4; // minutes per epoch (example value)
    const timeRemaining = epochsRemaining * timePerEpoch;
    
    return {
      ...model,
      progress,
      timeRemaining
    };
  }
  
  async getAILearningMetrics() {
    const models = await db.query.aiModels.findMany({
      orderBy: desc(aiModels.updatedAt),
      limit: 1
    });
    
    if (models.length === 0) {
      return null;
    }
    
    return models[0];
  }
  
  async getNextActions() {
    const model = await this.getCurrentAIModel();
    
    if (!model) {
      return null;
    }
    
    const progress = (model.epoch / model.totalEpochs) * 100;
    const timeRemaining = model.timeRemaining;
    
    // These would normally come from a separate table
    return {
      trainingProgress: progress,
      timeRemaining,
      actions: [
        { id: 1, label: `Complete AI training (${Math.floor(timeRemaining / 60)}h ${timeRemaining % 60}m remaining)`, isCompleted: true },
        { id: 2, label: "Connect API keys for trading platforms", isCompleted: false },
        { id: 3, label: "Set risk management parameters", isCompleted: false },
        { id: 4, label: "Approve AI trading strategy allocation", isCompleted: false }
      ]
    };
  }
  
  // Assets methods
  async getAssets() {
    return await db.query.assets.findMany({
      with: {
        type: true
      }
    });
  }
  
  async getAssetPerformance() {
    return await db.query.performanceMetrics.findMany({
      with: {
        asset: {
          with: {
            type: true
          }
        }
      },
      orderBy: desc(performanceMetrics.updatedAt)
    });
  }
  
  // Market insights methods
  async getMarketInsights(timeRange = '7d') {
    let timeFilter;
    const now = new Date();
    
    switch (timeRange) {
      case '24h':
        timeFilter = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case '7d':
        timeFilter = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        timeFilter = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      default:
        timeFilter = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }
    
    return await db.query.marketInsights.findMany({
      where: gte(marketInsights.createdAt, timeFilter),
      orderBy: desc(marketInsights.createdAt)
    });
  }
  
  // Data sources methods
  async getDataSources() {
    return await db.query.dataSources.findMany();
  }
  
  // Strategies methods
  async getStrategies() {
    return await db.query.strategies.findMany({
      orderBy: desc(strategies.allocation)
    });
  }
  
  // Performance metrics methods
  async getPerformanceMetrics() {
    return await db.query.performanceMetrics.findMany({
      with: {
        asset: true,
        strategy: true
      }
    });
  }
}

export const storage = new Storage();
