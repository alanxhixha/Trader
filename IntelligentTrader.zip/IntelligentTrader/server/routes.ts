import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix
  const apiPrefix = '/api';

  // AI Model endpoints
  app.get(`${apiPrefix}/ai-model/current`, async (req, res) => {
    try {
      const currentModel = await storage.getCurrentAIModel();
      res.json(currentModel);
    } catch (error) {
      console.error('Error fetching current AI model:', error);
      res.status(500).json({ error: 'Failed to fetch current AI model' });
    }
  });

  app.get(`${apiPrefix}/ai-model/learning-metrics`, async (req, res) => {
    try {
      const metrics = await storage.getAILearningMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching AI learning metrics:', error);
      res.status(500).json({ error: 'Failed to fetch AI learning metrics' });
    }
  });

  app.get(`${apiPrefix}/ai-model/next-actions`, async (req, res) => {
    try {
      const actions = await storage.getNextActions();
      res.json(actions);
    } catch (error) {
      console.error('Error fetching next actions:', error);
      res.status(500).json({ error: 'Failed to fetch next actions' });
    }
  });

  // Assets endpoints
  app.get(`${apiPrefix}/assets`, async (req, res) => {
    try {
      const assets = await storage.getAssets();
      res.json(assets);
    } catch (error) {
      console.error('Error fetching assets:', error);
      res.status(500).json({ error: 'Failed to fetch assets' });
    }
  });

  app.get(`${apiPrefix}/assets/performance`, async (req, res) => {
    try {
      const performance = await storage.getAssetPerformance();
      res.json(performance);
    } catch (error) {
      console.error('Error fetching asset performance:', error);
      res.status(500).json({ error: 'Failed to fetch asset performance' });
    }
  });

  // Market insights endpoints
  app.get(`${apiPrefix}/market-insights`, async (req, res) => {
    try {
      const timeRange = req.query.timeRange as string || '7d';
      const insights = await storage.getMarketInsights(timeRange);
      res.json(insights);
    } catch (error) {
      console.error('Error fetching market insights:', error);
      res.status(500).json({ error: 'Failed to fetch market insights' });
    }
  });

  // Data sources endpoints
  app.get(`${apiPrefix}/data-sources`, async (req, res) => {
    try {
      const dataSources = await storage.getDataSources();
      res.json(dataSources);
    } catch (error) {
      console.error('Error fetching data sources:', error);
      res.status(500).json({ error: 'Failed to fetch data sources' });
    }
  });

  // Strategies endpoints
  app.get(`${apiPrefix}/strategies`, async (req, res) => {
    try {
      const strategies = await storage.getStrategies();
      res.json(strategies);
    } catch (error) {
      console.error('Error fetching strategies:', error);
      res.status(500).json({ error: 'Failed to fetch strategies' });
    }
  });

  // Performance metrics endpoints
  app.get(`${apiPrefix}/performance-metrics`, async (req, res) => {
    try {
      const metrics = await storage.getPerformanceMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching performance metrics:', error);
      res.status(500).json({ error: 'Failed to fetch performance metrics' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
