import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { useMobile } from "@/hooks/use-mobile";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export default function Settings() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar Navigation */}
      <Sidebar className={isMobile && !sidebarOpen ? "hidden" : ""} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <Header 
          title="Settings"
          subtitle="Configure your AI trading preferences"
          onMenuToggle={toggleSidebar}
        />
        
        {/* Settings Content */}
        <div className="p-4">
          <Tabs defaultValue="general" className="space-y-4">
            <TabsList className="grid grid-cols-4 w-full max-w-md">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="api-keys">API Keys</TabsTrigger>
              <TabsTrigger value="risk">Risk Management</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>General Settings</CardTitle>
                  <CardDescription>
                    Configure basic settings for your TradeSage AI system
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="system-name">System Name</Label>
                    <Input id="system-name" defaultValue="TradeSage AI" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="dark-mode">Dark Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable dark mode for the interface
                      </p>
                    </div>
                    <Switch id="dark-mode" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="auto-update">Auto Update</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically update market data
                      </p>
                    </div>
                    <Switch id="auto-update" defaultChecked />
                  </div>
                  
                  <Button>Save Changes</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="api-keys">
              <Card>
                <CardHeader>
                  <CardTitle>API Keys Configuration</CardTitle>
                  <CardDescription>
                    Manage API keys for different trading platforms and data providers
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="alpha-vantage-key">Alpha Vantage API Key</Label>
                    <Input id="alpha-vantage-key" type="password" placeholder="Enter API key" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="coingecko-key">CoinGecko API Key</Label>
                    <Input id="coingecko-key" type="password" placeholder="Enter API key" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="news-api-key">News API Key</Label>
                    <Input id="news-api-key" type="password" placeholder="Enter API key" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="economic-data-key">Economic Data API Key</Label>
                    <Input id="economic-data-key" type="password" placeholder="Enter API key" />
                  </div>
                  
                  <Button>Save API Keys</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="risk">
              <Card>
                <CardHeader>
                  <CardTitle>Risk Management</CardTitle>
                  <CardDescription>
                    Configure risk parameters for your AI trading system
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="max-allocation">Maximum Allocation per Asset (%)</Label>
                    <Input id="max-allocation" type="number" defaultValue="25" min="1" max="100" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="stop-loss">Default Stop Loss (%)</Label>
                    <Input id="stop-loss" type="number" defaultValue="5" min="1" max="50" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="take-profit">Default Take Profit (%)</Label>
                    <Input id="take-profit" type="number" defaultValue="15" min="1" max="100" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enable-risk-rules">Enable Risk Rules</Label>
                      <p className="text-sm text-muted-foreground">
                        Apply risk management rules to all trades
                      </p>
                    </div>
                    <Switch id="enable-risk-rules" defaultChecked />
                  </div>
                  
                  <Button>Save Risk Parameters</Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>
                    Configure how and when you receive notifications
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-notifications">Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive trading notifications via email
                      </p>
                    </div>
                    <Switch id="email-notifications" defaultChecked />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email-address">Email Address</Label>
                    <Input id="email-address" type="email" placeholder="your@email.com" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="trade-alerts">Trade Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Notifications for each trade execution
                      </p>
                    </div>
                    <Switch id="trade-alerts" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="market-insights">Market Insights</Label>
                      <p className="text-sm text-muted-foreground">
                        Notifications for new market insights
                      </p>
                    </div>
                    <Switch id="market-insights" defaultChecked />
                  </div>
                  
                  <Button>Save Notification Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
