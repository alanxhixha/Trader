import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { useMobile } from "@/hooks/use-mobile";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Portfolio() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar Navigation */}
      <Sidebar className={isMobile && !sidebarOpen ? "hidden" : ""} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <Header 
          title="Portfolio"
          subtitle="Manage your AI-powered investment portfolio"
          onMenuToggle={toggleSidebar}
        />
        
        {/* Portfolio Content */}
        <div className="p-4">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Portfolio Management</CardTitle>
              <CardDescription>
                Intelligent portfolio management and allocation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <h3 className="text-lg font-semibold mb-2">Coming Soon</h3>
                <p className="text-muted-foreground">
                  The Portfolio Management module is currently in development. Check back soon for AI-powered
                  portfolio allocation, risk management, and performance tracking.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
