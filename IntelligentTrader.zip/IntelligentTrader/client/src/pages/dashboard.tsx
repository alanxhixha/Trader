import { useState } from "react";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import TrainingStatus from "@/components/dashboard/training-status";
import PerformanceCard from "@/components/dashboard/performance-card";
import MarketInsights from "@/components/dashboard/market-insights";
import NextActions from "@/components/dashboard/next-actions";
import AssetsTable from "@/components/dashboard/assets-table";
import AILearningMetrics from "@/components/dashboard/ai-learning-metrics";
import { useMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar Navigation */}
      <Sidebar className={isMobile && !sidebarOpen ? "hidden" : ""} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <Header 
          title="AI Trading Dashboard"
          subtitle="Real-time market analysis and intelligent trading"
          onMenuToggle={toggleSidebar}
        />
        
        {/* Dashboard Content */}
        <div className="p-4">
          {/* AI Training Status Section */}
          <TrainingStatus />
          
          {/* Performance Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <PerformanceCard 
              title="BACKTESTING PERFORMANCE"
              value="+23.7%"
              trend={{ value: 4.2, direction: 'up' }}
              chartType="bar"
              period="6m"
            />
            
            <PerformanceCard 
              title="WIN/LOSS RATIO"
              value="3.2:1"
              trend={{ value: 0.4, direction: 'up' }}
              chartType="ratio"
            />
            
            <PerformanceCard 
              title="STRATEGY ALLOCATION"
              value="5 Active"
              trend={{ value: 0, direction: 'neutral' }}
              chartType="allocation"
            />
          </div>
          
          {/* Insights and Recommendation Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2">
              <MarketInsights />
            </div>
            
            <div>
              <NextActions />
            </div>
          </div>
          
          {/* Assets Under Management */}
          <AssetsTable />
          
          {/* AI Learning Progress */}
          <AILearningMetrics />
        </div>
      </main>
    </div>
  );
}
