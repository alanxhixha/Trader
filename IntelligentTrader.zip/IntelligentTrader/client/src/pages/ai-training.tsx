import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { useMobile } from "@/hooks/use-mobile";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

export default function AITraining() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar Navigation */}
      <Sidebar className={isMobile && !sidebarOpen ? "hidden" : ""} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <Header 
          title="AI Training"
          subtitle="Configure and monitor your AI training process"
          onMenuToggle={toggleSidebar}
        />
        
        {/* AI Training Content */}
        <div className="p-4">
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="grid grid-cols-4 w-full max-w-md">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="models">Models</TabsTrigger>
              <TabsTrigger value="data">Data Sources</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Training Progress</CardTitle>
                  <CardDescription>
                    Your AI model is currently in the training phase, learning patterns from historical market data.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Current epoch: 257/500</span>
                      <span>51.4% Complete</span>
                    </div>
                    <Progress value={51.4} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Accuracy</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold mono">87.2%</div>
                        <div className="text-xs text-success">
                          <i className="fas fa-arrow-up mr-1"></i> 2.4% since last epoch
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Loss Function</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold mono">0.142</div>
                        <div className="text-xs text-success">
                          <i className="fas fa-arrow-down mr-1"></i> 0.08 since last epoch
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="py-3">
                        <CardTitle className="text-sm">Time Remaining</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold mono">4h 32m</div>
                        <div className="text-xs text-muted-foreground">
                          At current processing rate
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline">Pause Training</Button>
                    <Button>Adjust Parameters</Button>
                  </div>
                </CardContent>
              </Card>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Training Data Breakdown</CardTitle>
                    <CardDescription>
                      Distribution of data types used in the current training session
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Market Price Data</span>
                          <span className="mono">65%</span>
                        </div>
                        <Progress value={65} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Sentiment Analysis</span>
                          <span className="mono">20%</span>
                        </div>
                        <Progress value={20} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Economic Indicators</span>
                          <span className="mono">10%</span>
                        </div>
                        <Progress value={10} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>News & Events</span>
                          <span className="mono">5%</span>
                        </div>
                        <Progress value={5} className="h-2 bg-background" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Hardware Utilization</CardTitle>
                    <CardDescription>
                      Current system resource usage for AI training
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>CPU Usage</span>
                          <span className="mono">72%</span>
                        </div>
                        <Progress value={72} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Memory Usage</span>
                          <span className="mono">2.4GB / 4.0GB</span>
                        </div>
                        <Progress value={60} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>GPU Utilization</span>
                          <span className="mono">85%</span>
                        </div>
                        <Progress value={85} className="h-2 bg-background" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Network I/O</span>
                          <span className="mono">12MB/s</span>
                        </div>
                        <Progress value={40} className="h-2 bg-background" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="models">
              <Card>
                <CardHeader>
                  <CardTitle>AI Models</CardTitle>
                  <CardDescription>
                    Manage trained and in-progress AI models
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">This section is under development</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="data">
              <Card>
                <CardHeader>
                  <CardTitle>Data Sources</CardTitle>
                  <CardDescription>
                    Configure and manage data sources for AI training
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">This section is under development</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Training Settings</CardTitle>
                  <CardDescription>
                    Configure parameters and settings for the AI training process
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">This section is under development</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
