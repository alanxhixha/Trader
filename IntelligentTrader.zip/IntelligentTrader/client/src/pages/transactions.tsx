import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { useMobile } from "@/hooks/use-mobile";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Transactions() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar Navigation */}
      <Sidebar className={isMobile && !sidebarOpen ? "hidden" : ""} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <Header 
          title="Transactions"
          subtitle="Monitor your AI trading activities"
          onMenuToggle={toggleSidebar}
        />
        
        {/* Transactions Content */}
        <div className="p-4">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>
                History of AI-executed trading activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <h3 className="text-lg font-semibold mb-2">Coming Soon</h3>
                <p className="text-muted-foreground">
                  The Transaction History module is currently in development. Check back soon for a detailed
                  record of all trading activities performed by your AI trading system.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
