import { cn } from "@/lib/utils";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMobile } from "@/hooks/use-mobile";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const isMobile = useMobile();
  const [isOpen, setIsOpen] = useState(!isMobile);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const navItems = [
    { icon: "fa-chart-line", label: "Dashboard", href: "/" },
    { icon: "fa-brain", label: "AI Training", href: "/ai-training" },
    { icon: "fa-search-dollar", label: "Market Research", href: "/market-research" },
    { icon: "fa-wallet", label: "Portfolio", href: "/portfolio" },
    { icon: "fa-exchange-alt", label: "Transactions", href: "/transactions" },
    { icon: "fa-chart-pie", label: "Performance", href: "/performance" },
    { icon: "fa-cog", label: "Settings", href: "/settings" },
  ];

  return (
    <aside className={cn("bg-card flex-shrink-0 border-r border-gray-800 flex flex-col h-full", 
      isMobile ? (isOpen ? "w-full absolute z-50 h-screen" : "hidden") : "w-64",
      className)}>
      <div className="p-4 border-b border-gray-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <i className="fas fa-robot text-white"></i>
          </div>
          <h1 className="font-bold text-lg text-white">TradeSage AI</h1>
        </div>
        {isMobile && (
          <button onClick={toggleSidebar} className="text-gray-400 hover:text-white">
            <i className="fas fa-times"></i>
          </button>
        )}
      </div>
      
      <nav className="p-4 flex-grow">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link 
                href={item.href} 
                className={cn(
                  "flex items-center py-2 px-4 rounded-md",
                  location === item.href 
                    ? "bg-primary bg-opacity-20 text-primary-light" 
                    : "text-gray-400 hover:text-white hover:bg-background"
                )}
              >
                <i className={`fas ${item.icon} w-5 mr-2`}></i>
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* AI Status Section */}
      <div className="p-4 border-t border-gray-800 mt-auto">
        <div className="bg-background p-3 rounded-md">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs text-gray-400">AI STATUS</h3>
            <span className="bg-success px-2 py-0.5 rounded-full text-xs font-medium">Active</span>
          </div>
          <div className="flex flex-col">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs">CPU Usage</span>
              <span className="text-xs mono text-primary-light">72%</span>
            </div>
            <div className="w-full bg-background rounded-full h-1 mb-2">
              <div className="bg-primary h-1 rounded-full" style={{ width: '72%' }}></div>
            </div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs">Memory</span>
              <span className="text-xs mono text-primary-light">2.4GB</span>
            </div>
            <div className="w-full bg-background rounded-full h-1 mb-2">
              <div className="bg-primary h-1 rounded-full" style={{ width: '60%' }}></div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
