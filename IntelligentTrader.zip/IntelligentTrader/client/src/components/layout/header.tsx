import { useState } from "react";
import { useMobile } from "@/hooks/use-mobile";

interface HeaderProps {
  title: string;
  subtitle?: string;
  onMenuToggle?: () => void;
}

export function Header({ title, subtitle, onMenuToggle }: HeaderProps) {
  const [mode, setMode] = useState<'training' | 'live'>('training');
  const isMobile = useMobile();
  
  const toggleMode = (newMode: 'training' | 'live') => {
    setMode(newMode);
  };

  const currentDate = new Date().toLocaleDateString('en-US', { 
    month: 'long', 
    day: 'numeric', 
    year: 'numeric' 
  });

  return (
    <header className="bg-card p-4 border-b border-gray-800 flex justify-between items-center sticky top-0 z-10">
      <div>
        <h1 className="text-xl font-semibold">{title}</h1>
        {subtitle && <p className="text-gray-400 text-sm">{subtitle}</p>}
      </div>
      <div className="flex items-center space-x-4">
        {isMobile && (
          <button 
            onClick={onMenuToggle} 
            className="text-gray-400 hover:text-white"
          >
            <i className="fas fa-bars"></i>
          </button>
        )}
        <div className="flex items-center bg-background rounded-md p-1">
          <button 
            className={`py-1 px-3 text-sm font-medium rounded-md ${
              mode === 'training' ? 'bg-primary text-white' : 'text-gray-400'
            }`}
            onClick={() => toggleMode('training')}
          >
            Training
          </button>
          <button 
            className={`py-1 px-3 text-sm font-medium rounded-md ${
              mode === 'live' ? 'bg-primary text-white' : 'text-gray-400'
            }`}
            onClick={() => toggleMode('live')}
          >
            Live Trading
          </button>
        </div>
        <div className="hidden sm:flex items-center space-x-2 bg-background rounded-md px-3 py-1.5">
          <i className="fas fa-calendar-alt text-gray-400"></i>
          <span className="text-sm text-gray-300">{currentDate}</span>
        </div>
        <div className="relative">
          <button className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <i className="fas fa-user-alt text-white"></i>
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;
