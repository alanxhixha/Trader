import { getRelativeTime } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface InsightTag {
  label: string;
  type?: 'default' | 'success' | 'warning' | 'primary' | 'danger';
}

interface MarketInsight {
  id: number;
  title: string;
  description: string;
  createdAt: string;
  severity: 'success' | 'warning' | 'primary' | 'danger';
  tags: InsightTag[];
}

export function MarketInsights() {
  const [timeRange, setTimeRange] = useState<string>('7d');
  
  const { data: insights, isLoading } = useQuery<MarketInsight[]>({
    queryKey: ['/api/market-insights', timeRange],
  });

  const handleTimeRangeChange = (range: string) => {
    setTimeRange(range);
  };

  const getSeverityBorderClass = (severity: string) => {
    switch (severity) {
      case 'success': return 'border-success';
      case 'warning': return 'border-warning';
      case 'primary': return 'border-primary';
      case 'danger': return 'border-danger';
      default: return 'border-neutral';
    }
  };

  const getTagClass = (type: string = 'default') => {
    switch (type) {
      case 'success': return 'bg-success bg-opacity-20 text-success';
      case 'warning': return 'bg-warning bg-opacity-20 text-warning';
      case 'primary': return 'bg-primary bg-opacity-20 text-primary-light';
      case 'danger': return 'bg-danger bg-opacity-20 text-danger';
      default: return 'bg-background';
    }
  };

  // Default insights if API doesn't return data
  const defaultInsights: MarketInsight[] = [
    {
      id: 1,
      title: 'Bull Market Trend Detected',
      description: 'Analysis of market indicators suggests a bullish trend forming across tech sectors. Pattern recognition models indicate 78% probability of continuation.',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      severity: 'success',
      tags: [
        { label: 'Tech Sector' },
        { label: 'Bullish' },
        { label: 'High Confidence', type: 'success' }
      ]
    },
    {
      id: 2,
      title: 'Cryptocurrency Volatility Increasing',
      description: 'Volatility metrics indicate increased fluctuation in major cryptocurrencies. Model suggests a 63% probability of a short-term correction followed by recovery.',
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
      severity: 'warning',
      tags: [
        { label: 'Cryptocurrency' },
        { label: 'Volatile' },
        { label: 'Medium Confidence', type: 'warning' }
      ]
    },
    {
      id: 3,
      title: 'Sector Rotation Opportunity',
      description: 'Economic indicators and sentiment analysis suggest rotation from growth to value stocks. Model predicts outperformance in financial and energy sectors.',
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
      severity: 'primary',
      tags: [
        { label: 'Sector Rotation' },
        { label: 'Value Stocks' },
        { label: 'Actionable', type: 'primary' }
      ]
    },
    {
      id: 4,
      title: 'Risk Alert: Commodity Pressure',
      description: 'Supply chain analysis indicates potential pricing pressure in industrial commodities. Model suggests hedging exposure in manufacturing and materials sectors.',
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      severity: 'danger',
      tags: [
        { label: 'Commodities' },
        { label: 'Risk Management' },
        { label: 'Caution', type: 'danger' }
      ]
    }
  ];

  const displayInsights = insights || defaultInsights;

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg p-4 h-full">
        <div className="flex justify-between items-center mb-4">
          <Skeleton className="h-6 w-48" />
          <div className="flex space-x-2">
            <Skeleton className="h-8 w-12" />
            <Skeleton className="h-8 w-12" />
            <Skeleton className="h-8 w-12" />
          </div>
        </div>
        
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="border-l-2 border-gray-600 pl-4 py-2">
              <Skeleton className="h-5 w-full max-w-[250px] mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg p-4 h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold">AI Market Insights & Recommendations</h2>
        <div className="flex space-x-2">
          <button 
            onClick={() => handleTimeRangeChange('24h')}
            className={`px-2 py-1 text-xs rounded-md ${timeRange === '24h' ? 'bg-primary text-white' : 'bg-background text-gray-400 hover:text-white'}`}
          >
            24h
          </button>
          <button 
            onClick={() => handleTimeRangeChange('7d')}
            className={`px-2 py-1 text-xs rounded-md ${timeRange === '7d' ? 'bg-primary text-white' : 'bg-background text-gray-400 hover:text-white'}`}
          >
            7d
          </button>
          <button 
            onClick={() => handleTimeRangeChange('30d')}
            className={`px-2 py-1 text-xs rounded-md ${timeRange === '30d' ? 'bg-primary text-white' : 'bg-background text-gray-400 hover:text-white'}`}
          >
            30d
          </button>
        </div>
      </div>
      
      <div className="overflow-auto max-h-80">
        {displayInsights.map((insight) => (
          <div key={insight.id} className={`border-l-2 ${getSeverityBorderClass(insight.severity)} pl-4 py-2 mb-4`}>
            <div className="flex justify-between">
              <h3 className="font-medium">{insight.title}</h3>
              <span className="text-xs text-gray-400">{getRelativeTime(insight.createdAt)}</span>
            </div>
            <p className="text-gray-400 text-sm mt-1">{insight.description}</p>
            <div className="flex flex-wrap space-x-2 mt-2">
              {insight.tags.map((tag, index) => (
                <span 
                  key={index} 
                  className={`${tag.type ? getTagClass(tag.type) : 'bg-background'} px-2 py-0.5 rounded-full text-xs`}
                >
                  {tag.label}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MarketInsights;
