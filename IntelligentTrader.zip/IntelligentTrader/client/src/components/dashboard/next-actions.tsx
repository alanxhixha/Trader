import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { formatTimeRemaining } from "@/lib/utils";

interface NextActionsProps {
  className?: string;
}

export function NextActions({ className }: NextActionsProps) {
  const { data: actionsData } = useQuery({
    queryKey: ['/api/ai-model/next-actions'],
  });

  // Default data if API doesn't return anything
  const data = actionsData || {
    trainingProgress: 51.4,
    timeRemaining: 272, // minutes
    actions: [
      { id: 1, label: "Complete AI training (4h 32m remaining)", isCompleted: true },
      { id: 2, label: "Connect API keys for trading platforms", isCompleted: false },
      { id: 3, label: "Set risk management parameters", isCompleted: false },
      { id: 4, label: "Approve AI trading strategy allocation", isCompleted: false }
    ]
  };

  return (
    <div className={`bg-card rounded-lg p-4 h-full ${className}`}>
      <h2 className="font-semibold mb-4">AI Next Actions</h2>
      
      <div className="bg-primary bg-opacity-10 border border-primary border-opacity-20 rounded-md p-3 mb-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-3">
              <i className="fas fa-robot text-white"></i>
            </div>
            <div>
              <h3 className="font-medium">Ready for Deployment</h3>
              <p className="text-xs text-gray-400">Training phase is {data.trainingProgress.toFixed(1)}% complete</p>
            </div>
          </div>
        </div>
        <div className="mt-3 pl-11">
          <p className="text-sm text-gray-300">Your AI trading system requires more training before it can be activated for live trading.</p>
        </div>
      </div>
      
      <h3 className="text-sm font-medium mb-2">Required Actions</h3>
      <ul className="space-y-3 mb-4">
        {data.actions.map(action => (
          <li key={action.id} className="flex items-center">
            <div className={`w-5 h-5 rounded-md border border-gray-600 flex-shrink-0 flex items-center justify-center mr-3 ${action.isCompleted ? 'bg-primary bg-opacity-10' : ''}`}>
              {action.isCompleted && <i className="fas fa-check text-xs text-primary-light"></i>}
            </div>
            <span className="text-sm">{action.label}</span>
          </li>
        ))}
      </ul>
      
      <Button className="w-full bg-primary hover:bg-primary-dark px-4 py-2 rounded-md text-white text-sm transition-colors">
        Continue AI Training
      </Button>
    </div>
  );
}

export default NextActions;
