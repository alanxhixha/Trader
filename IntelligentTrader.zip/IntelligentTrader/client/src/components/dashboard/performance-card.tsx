import { cn, formatPercent, formatRatio } from "@/lib/utils";

type ChartTypes = 'bar' | 'line' | 'allocation' | 'ratio';

interface PerformanceCardProps {
  title: string;
  value: string | number;
  trend?: {
    value: number;
    direction: 'up' | 'down' | 'neutral';
  };
  chartType: ChartTypes;
  chartData?: any;
  period?: string;
  className?: string;
}

export function PerformanceCard({ 
  title, 
  value, 
  trend, 
  chartType, 
  chartData, 
  period, 
  className 
}: PerformanceCardProps) {
  const renderTrendBadge = () => {
    if (!trend) return null;
    
    const { value, direction } = trend;
    const colorClass = direction === 'up' 
      ? 'bg-success bg-opacity-20 text-success' 
      : direction === 'down' 
        ? 'bg-danger bg-opacity-20 text-danger' 
        : 'bg-primary bg-opacity-20 text-primary-light';
    
    const iconClass = direction === 'up' 
      ? 'fa-arrow-up' 
      : direction === 'down' 
        ? 'fa-arrow-down' 
        : 'fa-check';
    
    return (
      <span className={`${colorClass} px-2 py-1 rounded-md text-xs`}>
        <i className={`fas ${iconClass} mr-1`}></i>
        {typeof value === 'number' ? (direction === 'up' || direction === 'down' ? formatPercent(value) : value) : value}
      </span>
    );
  };
  
  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return (
          <div className="relative h-full">
            <div className="absolute bottom-0 left-0 right-0 h-full flex items-end">
              <div className="flex-1 mx-0.5 h-[30%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[45%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[40%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[60%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[80%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[65%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[75%] bg-primary-light bg-opacity-20 hover:bg-opacity-40 rounded-sm transition-all"></div>
              <div className="flex-1 mx-0.5 h-[90%] bg-primary bg-opacity-70 hover:bg-opacity-90 rounded-sm transition-all"></div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center opacity-20">
              <svg className="w-full h-full" viewBox="0 0 400 150">
                <path d="M0,100 Q50,80 100,70 T200,50 T300,35 T400,30" fill="none" stroke="#0074D9" strokeWidth="2"></path>
              </svg>
            </div>
          </div>
        );
        
      case 'ratio':
        return (
          <div className="bg-background rounded-md p-3 h-full">
            <div className="flex justify-between mb-2">
              <span className="text-xs text-gray-400">Wins</span>
              <span className="text-xs mono">76.2%</span>
            </div>
            <div className="w-full bg-background rounded-full h-2 mb-3">
              <div className="bg-success h-2 rounded-full" style={{ width: '76.2%' }}></div>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-xs text-gray-400">Losses</span>
              <span className="text-xs mono">23.8%</span>
            </div>
            <div className="w-full bg-background rounded-full h-2 mb-3">
              <div className="bg-danger h-2 rounded-full" style={{ width: '23.8%' }}></div>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-xs text-gray-400">Average Win</span>
              <span className="text-xs mono text-success">+3.24%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-gray-400">Average Loss</span>
              <span className="text-xs mono text-danger">-1.18%</span>
            </div>
          </div>
        );
        
      case 'allocation':
        return (
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between py-2 border-b border-gray-800">
              <span className="text-xs">Trend Following</span>
              <div className="flex items-center">
                <div className="w-16 bg-background rounded-full h-1 mr-2">
                  <div className="bg-primary h-1 rounded-full" style={{ width: '42%' }}></div>
                </div>
                <span className="text-xs mono">42%</span>
              </div>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-gray-800">
              <span className="text-xs">Mean Reversion</span>
              <div className="flex items-center">
                <div className="w-16 bg-background rounded-full h-1 mr-2">
                  <div className="bg-primary h-1 rounded-full" style={{ width: '28%' }}></div>
                </div>
                <span className="text-xs mono">28%</span>
              </div>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-gray-800">
              <span className="text-xs">Breakout Trading</span>
              <div className="flex items-center">
                <div className="w-16 bg-background rounded-full h-1 mr-2">
                  <div className="bg-primary h-1 rounded-full" style={{ width: '15%' }}></div>
                </div>
                <span className="text-xs mono">15%</span>
              </div>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs">Other Strategies</span>
              <div className="flex items-center">
                <div className="w-16 bg-background rounded-full h-1 mr-2">
                  <div className="bg-primary h-1 rounded-full" style={{ width: '15%' }}></div>
                </div>
                <span className="text-xs mono">15%</span>
              </div>
            </div>
          </div>
        );
        
      default:
        return <div>No chart data</div>;
    }
  };
  
  return (
    <div className={cn("bg-card rounded-lg p-4", className)}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-gray-400 text-xs">{title}</h3>
          <p className="text-2xl font-semibold text-white mt-1">{value}</p>
        </div>
        {renderTrendBadge()}
      </div>
      <div className="chart-container">
        {renderChart()}
      </div>
      {period && (
        <div className="flex justify-between text-xs text-gray-400 mt-2">
          <span>Jan 2023</span>
          <span>Jun 2023</span>
        </div>
      )}
    </div>
  );
}

export default PerformanceCard;
