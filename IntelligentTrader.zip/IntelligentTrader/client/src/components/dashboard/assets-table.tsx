import { useQuery } from "@tanstack/react-query";
import { formatPercent } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

interface AssetPerformance {
  id: number;
  asset: {
    id: number;
    name: string;
    symbol: string;
    logoUrl: string;
    type: {
      id: number;
      name: string;
    }
  };
  testAllocation: number;
  backtestReturn: number;
  winRate: number;
  confidence: number;
  status: string;
}

export function AssetsTable() {
  const { data: assetPerformance, isLoading } = useQuery<AssetPerformance[]>({
    queryKey: ['/api/assets/performance'],
  });

  const getStatusBadge = (status: string) => {
    const statusClasses: Record<string, string> = {
      'Optimized': 'bg-success bg-opacity-20 text-success',
      'Learning': 'bg-warning bg-opacity-20 text-warning',
      'In Progress': 'bg-primary bg-opacity-20 text-primary-light',
      'Needs Review': 'bg-danger bg-opacity-20 text-danger'
    };
    
    return (
      <span className={`${statusClasses[status] || 'bg-neutral bg-opacity-20 text-neutral'} px-2 py-0.5 rounded-full text-xs`}>
        {status}
      </span>
    );
  };
  
  const getAssetIcon = (asset: { name: string, symbol: string, logoUrl?: string }) => {
    const iconMap: Record<string, string> = {
      'Bitcoin': 'btc',
      'Ethereum': 'ethereum',
      'S&P 500': 'chart-line',
      'NVIDIA': 'microchip',
      'Gold': 'coins'
    };
    
    const colorMap: Record<string, string> = {
      'Bitcoin': 'blue-600',
      'Ethereum': 'purple-600',
      'S&P 500': 'gray-600',
      'NVIDIA': 'gray-600',
      'Gold': 'yellow-600'
    };
    
    const icon = iconMap[asset.name] || 'chart-line';
    const color = colorMap[asset.name] || 'gray-600';
    const isFabIcon = ['btc', 'ethereum'].includes(icon);
    
    return (
      <div className={`w-8 h-8 rounded-full bg-${color} flex items-center justify-center mr-2`}>
        <i className={`${isFabIcon ? 'fab' : 'fas'} fa-${icon} text-white text-xs`}></i>
      </div>
    );
  };
  
  // Default data if API doesn't return anything
  const defaultAssets = [
    {
      id: 1,
      asset: {
        id: 1,
        name: 'Bitcoin',
        symbol: 'BTC',
        logoUrl: '',
        type: { id: 1, name: 'Cryptocurrency' }
      },
      testAllocation: 25,
      backtestReturn: 31.4,
      winRate: 78,
      confidence: 85,
      status: 'Optimized'
    },
    {
      id: 2,
      asset: {
        id: 2,
        name: 'S&P 500',
        symbol: 'SPY',
        logoUrl: '',
        type: { id: 2, name: 'Index Fund' }
      },
      testAllocation: 20,
      backtestReturn: 18.2,
      winRate: 82,
      confidence: 90,
      status: 'Optimized'
    },
    {
      id: 3,
      asset: {
        id: 3,
        name: 'NVIDIA',
        symbol: 'NVDA',
        logoUrl: '',
        type: { id: 3, name: 'Stock' }
      },
      testAllocation: 15,
      backtestReturn: 42.8,
      winRate: 74,
      confidence: 70,
      status: 'Learning'
    },
    {
      id: 4,
      asset: {
        id: 4,
        name: 'Gold',
        symbol: 'GLD',
        logoUrl: '',
        type: { id: 4, name: 'Commodity' }
      },
      testAllocation: 10,
      backtestReturn: -4.2,
      winRate: 45,
      confidence: 45,
      status: 'Needs Review'
    },
    {
      id: 5,
      asset: {
        id: 5,
        name: 'Ethereum',
        symbol: 'ETH',
        logoUrl: '',
        type: { id: 1, name: 'Cryptocurrency' }
      },
      testAllocation: 20,
      backtestReturn: 27.6,
      winRate: 72,
      confidence: 75,
      status: 'In Progress'
    }
  ];
  
  const displayAssets = assetPerformance || defaultAssets;
  
  if (isLoading) {
    return (
      <div className="bg-card rounded-lg p-4 mb-6">
        <div className="flex justify-between items-center mb-4">
          <Skeleton className="h-6 w-64" />
          <Skeleton className="h-8 w-24" />
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-xs text-left text-gray-400 border-b border-gray-800">
                <th className="pb-2 font-medium">ASSET</th>
                <th className="pb-2 font-medium">TYPE</th>
                <th className="pb-2 font-medium">TEST ALLOCATION</th>
                <th className="pb-2 font-medium">BACKTESTED RETURN</th>
                <th className="pb-2 font-medium">WIN RATE</th>
                <th className="pb-2 font-medium">CONFIDENCE</th>
                <th className="pb-2 font-medium">STATUS</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-b border-gray-800">
                  <td className="py-3">
                    <div className="flex items-center">
                      <Skeleton className="w-8 h-8 rounded-full mr-2" />
                      <div>
                        <Skeleton className="h-4 w-20 mb-1" />
                        <Skeleton className="h-3 w-10" />
                      </div>
                    </div>
                  </td>
                  <td className="py-3"><Skeleton className="h-4 w-24" /></td>
                  <td className="py-3"><Skeleton className="h-4 w-12" /></td>
                  <td className="py-3"><Skeleton className="h-4 w-16" /></td>
                  <td className="py-3"><Skeleton className="h-4 w-12" /></td>
                  <td className="py-3"><Skeleton className="h-2 w-full" /></td>
                  <td className="py-3"><Skeleton className="h-6 w-20 rounded-full" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-card rounded-lg p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold">Training Assets & Historical Performance</h2>
        <button className="text-xs text-primary-light hover:text-white">
          <i className="fas fa-cog mr-1"></i> Configure
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="text-xs text-left text-gray-400 border-b border-gray-800">
              <th className="pb-2 font-medium">ASSET</th>
              <th className="pb-2 font-medium">TYPE</th>
              <th className="pb-2 font-medium">TEST ALLOCATION</th>
              <th className="pb-2 font-medium">BACKTESTED RETURN</th>
              <th className="pb-2 font-medium">WIN RATE</th>
              <th className="pb-2 font-medium">CONFIDENCE</th>
              <th className="pb-2 font-medium">STATUS</th>
            </tr>
          </thead>
          <tbody>
            {displayAssets.map((item) => (
              <tr key={item.id} className="border-b border-gray-800 text-sm">
                <td className="py-3">
                  <div className="flex items-center">
                    {getAssetIcon(item.asset)}
                    <div>
                      <span className="font-medium">{item.asset.name}</span>
                      <span className="text-xs text-gray-400 block">{item.asset.symbol}</span>
                    </div>
                  </div>
                </td>
                <td className="py-3">{item.asset.type.name}</td>
                <td className="py-3 mono">{item.testAllocation}%</td>
                <td className="py-3 mono text-success">{formatPercent(item.backtestReturn)}</td>
                <td className="py-3 mono">{item.winRate}%</td>
                <td className="py-3">
                  <div className="w-full bg-background rounded-full h-1">
                    <div className={`${item.confidence >= 80 ? 'bg-success' : item.confidence >= 60 ? 'bg-primary' : 'bg-danger'} h-1 rounded-full`} style={{ width: `${item.confidence}%` }}></div>
                  </div>
                </td>
                <td className="py-3">
                  {getStatusBadge(item.status)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AssetsTable;
