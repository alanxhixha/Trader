import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDataSize } from "@/lib/utils";

interface AiModel {
  id: number;
  accuracy: number;
  accuracyTrend: number;
  precision: number;
  precisionTrend: number;
  recall: number;
  recallTrend: number;
  f1Score: number;
  f1ScoreTrend: number;
  networkDepth: number;
  parameters: string;
  optimizationAlgorithm: string;
  learningRate: number;
  lastUpdated: string;
}

interface DataSource {
  id: number;
  name: string;
  description: string;
  type: string;
  icon: string;
  isConnected: boolean;
}

interface AILearningMetricsProps {
  className?: string;
}

export function AILearningMetrics({ className }: AILearningMetricsProps) {
  const { data: aiModel, isLoading: isModelLoading } = useQuery<AiModel>({
    queryKey: ['/api/ai-model/learning-metrics'],
  });
  
  const { data: dataSources, isLoading: isSourcesLoading } = useQuery<DataSource[]>({
    queryKey: ['/api/data-sources'],
  });
  
  // Default data if API doesn't return anything
  const defaultModel: AiModel = {
    id: 1,
    accuracy: 87.2,
    accuracyTrend: 2.4,
    precision: 82.7,
    precisionTrend: 1.8,
    recall: 79.4,
    recallTrend: 3.1,
    f1Score: 81.0,
    f1ScoreTrend: 2.5,
    networkDepth: 7,
    parameters: '145.6M',
    optimizationAlgorithm: 'Adam',
    learningRate: 0.0001,
    lastUpdated: new Date(Date.now() - 14 * 60 * 1000).toISOString() // 14 minutes ago
  };
  
  const defaultSources: DataSource[] = [
    {
      id: 1,
      name: 'Alpha Vantage API',
      description: 'Stock market data',
      type: 'Market Data',
      icon: 'chart-bar',
      isConnected: true
    },
    {
      id: 2,
      name: 'CoinGecko API',
      description: 'Cryptocurrency data',
      type: 'Crypto Data',
      icon: 'bitcoin',
      isConnected: true
    },
    {
      id: 3,
      name: 'News API',
      description: 'Market news & sentiment',
      type: 'News',
      icon: 'newspaper',
      isConnected: true
    },
    {
      id: 4,
      name: 'Economic Indicators',
      description: 'Macroeconomic data',
      type: 'Economic',
      icon: 'dollar-sign',
      isConnected: false
    }
  ];
  
  const model = aiModel || defaultModel;
  const sources = dataSources || defaultSources;
  
  const lastUpdatedTime = model.lastUpdated 
    ? new Date(model.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : '';
  
  const getTrendBadge = (value: number) => {
    if (value === 0) return null;
    
    const direction = value > 0 ? 'up' : 'down';
    const color = value > 0 ? 'success' : 'danger';
    
    return (
      <span className={`text-xs text-${color} ml-2 mb-1`}>
        <i className={`fas fa-arrow-${direction} mr-1`}></i>
        {Math.abs(value).toFixed(1)}%
      </span>
    );
  };
  
  if (isModelLoading || isSourcesLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-36" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-background p-3 rounded-md">
                <Skeleton className="h-3 w-16 mb-2" />
                <Skeleton className="h-6 w-20" />
              </div>
            ))}
          </div>
          
          <Skeleton className="h-5 w-36 mb-2" />
          <div className="bg-background p-3 rounded-md">
            <div className="space-y-2">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex justify-between">
                  <Skeleton className="h-3 w-32" />
                  <Skeleton className="h-3 w-16" />
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="bg-card rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-24" />
          </div>
          
          <div className="space-y-3 mb-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center justify-between bg-background p-3 rounded-md">
                <div className="flex items-center">
                  <Skeleton className="w-8 h-8 rounded-full mr-3" />
                  <div>
                    <Skeleton className="h-4 w-28 mb-1" />
                    <Skeleton className="h-3 w-20" />
                  </div>
                </div>
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
            ))}
          </div>
          
          <div className="flex justify-between">
            <Skeleton className="h-3 w-32" />
            <Skeleton className="h-3 w-32" />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 ${className}`}>
      <div className="bg-card rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold">AI Learning Metrics</h2>
          <div className="text-xs text-gray-400">Last updated: {lastUpdatedTime || '14 minutes ago'}</div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-background p-3 rounded-md">
            <h3 className="text-xs text-gray-400 mb-1">ACCURACY</h3>
            <div className="flex items-end">
              <span className="text-xl font-semibold mono">{model.accuracy.toFixed(1)}%</span>
              {getTrendBadge(model.accuracyTrend)}
            </div>
          </div>
          <div className="bg-background p-3 rounded-md">
            <h3 className="text-xs text-gray-400 mb-1">PRECISION</h3>
            <div className="flex items-end">
              <span className="text-xl font-semibold mono">{model.precision.toFixed(1)}%</span>
              {getTrendBadge(model.precisionTrend)}
            </div>
          </div>
          <div className="bg-background p-3 rounded-md">
            <h3 className="text-xs text-gray-400 mb-1">RECALL</h3>
            <div className="flex items-end">
              <span className="text-xl font-semibold mono">{model.recall.toFixed(1)}%</span>
              {getTrendBadge(model.recallTrend)}
            </div>
          </div>
          <div className="bg-background p-3 rounded-md">
            <h3 className="text-xs text-gray-400 mb-1">F1 SCORE</h3>
            <div className="flex items-end">
              <span className="text-xl font-semibold mono">{model.f1Score.toFixed(1)}%</span>
              {getTrendBadge(model.f1ScoreTrend)}
            </div>
          </div>
        </div>
        
        <h3 className="text-sm font-medium mb-2">Model Evolution</h3>
        <div className="bg-background p-3 rounded-md">
          <div className="flex justify-between mb-1">
            <span className="text-xs">Neural Network Depth</span>
            <span className="text-xs mono">{model.networkDepth} layers</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-xs">Parameters</span>
            <span className="text-xs mono">{model.parameters}</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-xs">Optimization Algorithm</span>
            <span className="text-xs mono">{model.optimizationAlgorithm}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs">Learning Rate</span>
            <span className="text-xs mono">{model.learningRate}</span>
          </div>
        </div>
      </div>
      
      <div className="bg-card rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold">Market Data Sources</h2>
          <button className="text-xs text-primary-light hover:text-white">
            <i className="fas fa-plus mr-1"></i> Add Source
          </button>
        </div>
        
        <div className="space-y-3 mb-4">
          {sources.map((source) => (
            <div key={source.id} className="flex items-center justify-between bg-background p-3 rounded-md">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                  <i className={`${source.icon && source.icon.includes('bitcoin') ? 'fab' : 'fas'} fa-${source.icon || 'chart-line'} text-white text-xs`}></i>
                </div>
                <div>
                  <h3 className="font-medium text-sm">{source.name}</h3>
                  <p className="text-xs text-gray-400">{source.description}</p>
                </div>
              </div>
              <span className={`${source.isConnected ? 'bg-success' : 'bg-warning'} px-2 py-0.5 rounded-full text-xs`}>
                {source.isConnected ? 'Connected' : 'Needs Setup'}
              </span>
            </div>
          ))}
        </div>
        
        <div className="flex justify-between text-xs text-gray-400 mt-2">
          <span>Data points collected: 4.2TB</span>
          <span>Historical range: 10 years</span>
        </div>
      </div>
    </div>
  );
}

export default AILearningMetrics;
