import { formatTimeRemaining } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export function TrainingStatus() {
  const { data: aiModel, isLoading } = useQuery({
    queryKey: ['/api/ai-model/current'],
  });

  if (isLoading) {
    return (
      <div className="bg-gradient-to-r from-card to-primary bg-opacity-50 rounded-lg p-6 mb-6">
        <div className="animate-pulse">
          <div className="h-5 bg-muted rounded w-1/4 mb-4"></div>
          <div className="h-4 bg-muted rounded w-2/3 mb-6"></div>
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="bg-background bg-opacity-50 p-3 rounded-md w-32 h-24"></div>
            <div className="bg-background bg-opacity-50 p-3 rounded-md w-32 h-24"></div>
            <div className="bg-background bg-opacity-50 p-3 rounded-md w-32 h-24"></div>
          </div>
        </div>
      </div>
    );
  }

  // Default values if API doesn't return data
  const model = aiModel || {
    epoch: 257,
    totalEpochs: 500,
    accuracy: 87.2,
    dataProcessed: 4.2, // TB
    progress: 51.4, // %
    timeRemaining: 272 // minutes
  };

  const progress = (model.epoch / model.totalEpochs) * 100;
  
  return (
    <div className="bg-gradient-to-r from-card to-primary bg-opacity-50 rounded-lg p-6 mb-6">
      <div className="flex flex-col md:flex-row justify-between">
        <div>
          <h2 className="text-lg font-semibold mb-2">AI Training Progress</h2>
          <p className="text-gray-300 mb-4">Your AI is currently in training mode, analyzing historical market data and optimizing strategies.</p>
          
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="bg-background bg-opacity-50 p-3 rounded-md">
              <h3 className="text-xs text-gray-400 mb-1">TRAINING EPOCH</h3>
              <p className="text-xl font-semibold mono">{model.epoch} <span className="text-sm text-gray-400">/{model.totalEpochs}</span></p>
            </div>
            <div className="bg-background bg-opacity-50 p-3 rounded-md">
              <h3 className="text-xs text-gray-400 mb-1">ACCURACY SCORE</h3>
              <p className="text-xl font-semibold mono">{model.accuracy.toFixed(1)}<span className="text-sm">%</span></p>
            </div>
            <div className="bg-background bg-opacity-50 p-3 rounded-md">
              <h3 className="text-xs text-gray-400 mb-1">DATA PROCESSED</h3>
              <p className="text-xl font-semibold mono">{model.dataProcessed.toFixed(1)}<span className="text-sm">TB</span></p>
            </div>
          </div>
        </div>
        
        <div className="mt-4 md:mt-0">
          <div className="bg-background bg-opacity-70 p-4 rounded-md">
            <h3 className="text-sm font-medium mb-3">Training Progress</h3>
            <div className="w-full bg-background rounded-full h-2 mb-3">
              <div className="bg-primary h-2 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <div className="flex justify-between text-xs text-gray-400">
              <span>{progress.toFixed(1)}% Complete</span>
              <span>Est. time remaining: {formatTimeRemaining(model.timeRemaining)}</span>
            </div>
            <div className="mt-4">
              <Button className="bg-primary px-4 py-2 rounded-md text-white text-sm hover:bg-primary-dark transition-colors">
                View Detailed Analysis
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TrainingStatus;
